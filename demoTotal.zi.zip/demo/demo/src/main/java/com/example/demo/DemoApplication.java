package com.example.demo;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@SpringBootApplication
@RestController
public class DemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Operation(summary = "Lee el contenido de un archivo")
    @GetMapping("/cat")
    public String catFile(@RequestParam String filePath) {
        Path path = Paths.get(filePath); // Crear un objeto Path a partir de la ruta del archivo

        // Verificar si el archivo existe
        if (!Files.exists(path)) {
            return "Error: El archivo no existe en la ruta especificada: " + filePath;
        }

        try {
            // Leer el contenido del archivo
            String content = new String(Files.readAllBytes(path));
            return content;
        } catch (IOException e) {
            e.printStackTrace();
            return "Error al leer el archivo: " + e.getMessage();
        }
    }

    @Operation(summary = "Clona un repositorio de Git usando un token")
    @PostMapping("/clone")
    public String cloneRepo(
            @Parameter(description = "URL del repositorio a clonar", required = true) @RequestParam String repoUrl,
            @Parameter(description = "Directorio donde se clonará el repositorio", required = true) @RequestParam String directory,
            @Parameter(description = "Token de acceso para autenticación", required = true) @RequestParam @Schema(hidden = true, type = "string", format = "password") String token) {

        File dir = new File(directory);
        if (dir.exists()) {
            return "Error: La carpeta ya existe en la ruta: " + directory;
        }

        try {
            // Clona el repositorio usando únicamente el token
            Git git = Git.cloneRepository()
                    .setURI(repoUrl)
                    .setDirectory(dir)
                    .setCredentialsProvider(new UsernamePasswordCredentialsProvider("git", token)) // El nombre de usuario es un marcador, el token actúa como contraseña
                    .call();
            return "Repositorio clonado en: " + directory;
        } catch (GitAPIException e) {
            e.printStackTrace(); // Imprimir el stack trace para depuración
            return "Error al clonar el repositorio: " + e.getMessage();
        }
    }
}
